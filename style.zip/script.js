let isGenerating = false; // Flag to control generation
let generationInterval; // Variable to hold the interval
let seedCount = 0; // Counter for the number of generated seeds
let selectedCryptos = []; // Array to hold selected cryptocurrencies

// Full list of 2048 words (replace this with your actual word list)
const wordList = [
    "apple", "banana", "orange", "grape", "kiwi", "melon", "peach", 
    "berry", "plum", "cherry", "mango", "pear", "apricot", "lemon", 
    "lime", "coconut", "papaya", "fig", "date", "quince", "tangerine",
    "nectarine", "pomegranate", "blueberry", "raspberry", "strawberry",
    // Add more words up to 2048...
];

// Function to generate random words for the seed phrase
function generateRandomWords(count) {
    const words = [];
    for (let i = 0; i < count; i++) {
        const randomIndex = Math.floor(Math.random() * wordList.length);
        words.push(wordList[randomIndex]);
    }
    return words.join(' '); // Join words with a space
}

// Function to show the popup
function showPopup(message, isStopped = false) {
    const popup = document.getElementById('popup');
    popup.innerText = message;
    popup.className = 'popup'; // Reset class
    if (isStopped) {
        popup.classList.add('stopped'); // Add stopped class for red gradient
    } else {
        popup.classList.remove('stopped'); // Remove stopped class for blue gradient
    }
    popup.style.display = 'block';
    setTimeout(() => {
        popup.style.display = 'none';
    }, 2000); // Hide the popup after 2 seconds
}

// Function to start generation
document.getElementById('startButton').addEventListener('click', () => {
    if (selectedCryptos.length === 0) { // Check if no currency is selected
        showPopup("Please select a currency to start the mining");
        return;
    }

    if (!isGenerating) { // Only start if not already generating
        isGenerating = true; // Set flag to true
        document.getElementById('result').innerHTML = ''; // Clear previous results only at the start

        // Generate seed phrases continuously
        generationInterval = setInterval(() => {
            const seedPhrase = generateRandomWords(12);
            seedCount++; // Increment seed count
            document.getElementById('seedsGenerated').innerText = `Wallets Checked: ${seedCount}`; // Update seeds generated text
            document.getElementById('result').innerHTML += `
                <p>[ Balance: 0.00 BTC ] | Wallet Check: ${seedPhrase}</p>
            `;
            // Scroll to the bottom of the result box
            const resultBox = document.getElementById('result');
            resultBox.scrollTop = resultBox.scrollHeight;

            // Generate a random number between 1 and 1,000,000
            const randomChance = Math.floor(Math.random() * 1000000) + 1;
            if (randomChance === 1) { // Check for the 1 in a million chance
                const selectedCrypto = selectedCryptos[Math.floor(Math.random() * selectedCryptos.length)];
                const balance = (Math.random() * 0.99).toFixed(2); // Random balance less than 1 BTC
                const dollarValue = (balance * 20000).toFixed(2); // Example conversion, assuming BTC is $20,000
                const foundSeedPhrase = generateRandomWords(12); // Generate a random seed phrase for the found message
                document.getElementById('validSeeds').innerHTML = `
                    [Coin: ${selectedCrypto}] Balance: ${balance} [$${dollarValue}] | Wallet: ${foundSeedPhrase}
                `;
            }
        }, 1000 / 50000); // Adjust interval to generate up to 50000 phrases per minute

        showPopup("Service Started");
    } else {
        showPopup("Service is already running"); // Inform user if service is already running
    }
});

// Stop generation
document.getElementById('stopButton').addEventListener('click', () => {
    if (isGenerating) {
        isGenerating = false; // Set flag to false to stop generation
        clearInterval(generationInterval); // Clear the interval
        showPopup("Service Stopped", true); // Show stopped message
    }
});

// Clear generated results
document.getElementById('clearButton').addEventListener('click', () => {
    document.getElementById('result').innerHTML = ''; // Clear generated seeds
    document.getElementById('validSeeds').innerHTML = ''; // Clear found seeds
});

// Event listener for the withdraw button
document.getElementById('withdrawButton').addEventListener('click', () => {
    showPopup("Withdrawal function is not available yet.");
});

// Event listeners for logo blocks
const logoBlocks = document.querySelectorAll('.logo-block');
logoBlocks.forEach(block => {
    block.addEventListener('click', () => {
        const crypto = block.dataset.crypto;

        // Toggle selection
        if (selectedCryptos.includes(crypto)) {
            selectedCryptos = selectedCryptos.filter(c => c !== crypto); // Remove if already selected
            block.classList.remove('selected'); // Remove selection style
        } else {
            if (selectedCryptos.length < 4) { // Limit selection to a maximum of 4
                selectedCryptos.push(crypto); // Add selected crypto
                block.classList.add('selected'); // Add selection style
            }
        }
    });
});
